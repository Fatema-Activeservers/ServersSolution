  
           $(document).ready(function() {

            var counters = $(".count");
            var countersQuantity = counters.length;
            var counter = [];
            
            for (i = 0; i < countersQuantity; i++) {
              counter[i] = parseInt(counters[i].innerHTML);
            }
            
            var count = function(start, value, id) {
              var localStart = start;
              setInterval(function() {
                if (localStart < value) {
                  localStart++;
                  counters[id].innerHTML = localStart;
                }
              }, 40);
            }
            
            for (j = 0; j < countersQuantity; j++) {
              count(0, counter[j], j);
            }
            });
 
            $('.count').each(function () {
              $(this).prop('Counter',0).animate({
                Counter: $(this).text()
              }, {
                 duration: 3300,
                 easing: 'swing',
                 step: function (now) {
                  $(this).text(Math.ceil(now));
                }
              })
            })
            /*******/

















            const SubDropdown1 = document.getElementById("subdropdown1");
            SubDropdown1.style.display = 'none';

            const SubDropdown2 = document.getElementById("subdropdown2");
            SubDropdown2.style.display = 'none';

            const SubDropdown3 = document.getElementById("subdropdown3");
            SubDropdown3.style.display = 'none';

            const SubDropdown4 = document.getElementById("subdropdown4");
            SubDropdown4.style.display = 'none';

            const SubDropdown5 = document.getElementById("subdropdown5");
            SubDropdown5.style.display = 'none';

            const Product = document.getElementById("product")
            product.style.display = 'none';

            if(Product.ariaExpanded="False" || Product.style.display == 'none')
            {
              SubDropdown1.style.display = 'none';
              SubDropdown2.style.display = 'none';
              SubDropdown3.style.display = 'none';
              SubDropdown4.style.display = 'none';
              SubDropdown5.style.display = 'none';
            }



            

         function Toggle1()
         {
          SubDropdown1.style.display = 'block';
          SubDropdown2.style.display = 'none';
          SubDropdown3.style.display = 'none';
          SubDropdown4.style.display = 'none';
          SubDropdown5.style.display = 'none';
         }
         


         function Toggle2()
         {
          SubDropdown1.style.display = 'none';
          SubDropdown2.style.display = 'block';
          SubDropdown3.style.display = 'none';
          SubDropdown4.style.display = 'none';
          SubDropdown5.style.display = 'none';
         }
         

         function Toggle3()
         {
          SubDropdown1.style.display = 'none';
          SubDropdown2.style.display = 'none';
          SubDropdown3.style.display = 'block';
          SubDropdown4.style.display = 'none';
          SubDropdown5.style.display = 'none';
         }

         function Toggle4()
         {
          SubDropdown1.style.display = 'none';
          SubDropdown2.style.display = 'none';
          SubDropdown3.style.display = 'none';
          SubDropdown4.style.display = 'block';
          SubDropdown5.style.display = 'none';
         }

         function Toggle5()
         {
          SubDropdown1.style.display = 'none';
          SubDropdown2.style.display = 'none';
          SubDropdown3.style.display = 'none';
          SubDropdown4.style.display = 'none';
          SubDropdown5.style.display = 'block';
        }

        function HideAll()
        {
          SubDropdown1.style.display = 'none';
          SubDropdown2.style.display = 'none';
          SubDropdown3.style.display = 'none';
          SubDropdown4.style.display = 'none';
          SubDropdown5.style.display = 'none';          
        }


        
